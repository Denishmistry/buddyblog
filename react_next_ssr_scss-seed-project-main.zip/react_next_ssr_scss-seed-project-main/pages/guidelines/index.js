import React, { Component } from "react";
import { connect } from "react-redux";
import { Container, Row, Col, Button, Form, Dropdown } from 'react-bootstrap';
import Layout from "../../components/layout";
import DatePicker from "react-datepicker";

class Guidelines extends Component {
	/******************* 
	@purpose : Rander HTML/ React Components
	@Author : INIC
	******************/
	constructor(props, context) {
		super(props, context)
		this.state = {
			startDate: new Date()
		}
		this.handleChange = this.handleChange.bind(this);
	}
	handleChange(date) {
		this.setState({
		  startDate: date
		})
	}

	render() {
		// ReactSelectize
		var options = ["apple", "mango", "grapes", "melon", "strawberry"].map(function (fruit) {
			return { label: fruit, value: fruit }
		});

		return (
			<Layout>
				<div className="flex-shrink-0 my-5">
					<Container>
						<Row>
							<Col md={6}>
								<Form className="form-horizontal">
									<Form.Group controlId="formBasicEmail">
										<Form.Label>Email</Form.Label>
										<Form.Control type="email" placeholder="Enter email" />
									</Form.Group>

									<Form.Group controlId="passwordField">
										<Form.Label>Password</Form.Label>
										<Form.Control type="password" placeholder="Enter password" />
									</Form.Group>
								</Form>
							</Col>
						</Row>
					</Container>

					<Container>
						<div className="mt-4">
							<div className="mt-6">
								<h2 className="text-primary">Styling Icon</h2>
								<span className='bx bxs-like bx-xs'></span>
								<span className='bx bxs-like bx-sm'></span>
								<span className='bx bxs-like bx-md'></span>
								<span className='bx bxs-like bx-lg'></span>
							</div>
							<div className="mt-4">
								<h2 className="text-primary">Rotation & Flipping</h2>
								<span className='bx bxs-like bx-rotate-90'></span>
								<span className='bx bxs-like bx-rotate-180'></span>
								<span className='bx bxs-like bx-rotate-270'></span>
								<span className='bx bxs-like bx-flip-horizontal'></span>
								<span className='bx bxs-like bx-flip-vertical '></span>
							</div>
							<div className="mt-4">
								<h2 className="text-primary">List Icons</h2>
								<ul className='bx-ul'>
									<li><span className='bx bx-right-arrow'>List Item 1</span></li>
									<li><span className='bx bx-x'>List Item 2</span></li>
									<li><span className='bx bx-plus'>List Item 3</span></li>
								</ul>
							</div>
							<div className="mt-4">
								<h2 className="text-primary">Border</h2>
								<span className='bx bxs-heart bx-border'></span>
								<span className='bx bxs-heart bx-border-circle'></span>
							</div>
							<div className="mt-4">
								<h2 className="text-primary">Animation</h2>
								<span className='bx bxs-like bx-spin'></span>
								<span className='bx bxs-like bx-tada'></span>
								<span className='bx bxs-like bx-flashing'></span>
								<span className='bx bxs-like bx-burst'></span>
								<span className='bx bxs-like bx-fade-left'></span>
								<span className='bx bxs-like bx-fade-right'></span>
								<span className='bx bxs-like bx-fade-up'></span>
								<span className='bx bxs-like bx-fade-down'></span>
							</div>
							<div className="mt-4">
								<h2 className="text-primary">Animation with Splitting js</h2>
								<div data-splitting=''>Hello World!</div>
							</div>

							<div className="mt-4">
								<h2>more style visit boxincon site: <a href="https://boxicons.com/" target="_blank">https://boxicons.com/</a></h2>
							</div>
						</div>

						<div>
							<h2 className="text-primary">Buttons Style</h2>
							<Button className="mr-2" variant="primary" className="mr-2">Primary</Button>
							<Button className="mr-2" variant="secondary">Secondary</Button>
							<Button className="mr-2" variant="success">Success</Button>
							<Button className="mr-2" variant="warning">Warning</Button>
							<Button className="mr-2" variant="danger">Danger</Button> 
							<Button className="mr-2" variant="info">Info</Button>
							<Button className="mr-2" variant="light">Light</Button> 
							<Button className="mr-2" variant="dark">Dark</Button>
							<Button variant="link">Link</Button>
						</div>
						<div>
							<hr />
						</div>
						<div>
							<h4>Outline Buttons</h4>
							<Button className="mr-2" variant="outline-primary">Primary</Button>
							<Button className="mr-2" variant="outline-secondary">Secondary</Button>
							<Button className="mr-2" variant="outline-success">Success</Button>
							<Button className="mr-2" variant="outline-warning">Warning</Button>
							<Button className="mr-2" variant="outline-danger">Danger</Button>
							<Button className="mr-2" variant="outline-info">Info</Button>
							<Button className="mr-2" variant="outline-light">Light</Button>
							<Button variant="outline-dark">Dark</Button>
						</div>
						<div>
							<hr />
						</div>
						<div>
							<h4>Button Sizes</h4>
							<h6>Add .btn-lg or .btn-sm for additional sizes.</h6>
							<Button className="mr-2" variant="primary" size="lg">
								Primary Button Large
							</Button>
							<Button className="mr-2" variant="primary">
								Primary Button Normal
							</Button>
							<Button variant="primary" size="sm">
								Primary Button Small
							</Button>
						</div>
						<div>
							<hr />
						</div>
						<div>
							<h4>Button States</h4>
							<h6>Add .active for active state and .disabled class or disabled="disabled" attribute</h6>
							<Button className="mr-2" variant="primary" active>
								Primary Button Active States
							</Button>
							<Button variant="primary" disabled>
								Primary Button Disabled States
							</Button>
						</div>

						<div className="mt-4">
							<h2 className="text-primary">Dropdown Style</h2>
							<Dropdown>
								<Dropdown.Toggle variant="primary" id="dropdown-basic">
									Dropdown Button
								</Dropdown.Toggle>

								<Dropdown.Menu>
									<Dropdown.Item href="#/action-1">Action</Dropdown.Item>
									<Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
									<Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
								</Dropdown.Menu>
							</Dropdown>
						</div>

						<div className="mt-4">
							<div className="">
								<h2 className="text-primary">Checkbox and radio buttons</h2>
								<div className="btn-group btn-group-toggle" data-toggle="buttons">
									<label className="btn btn-primary active">
										<input type="radio" name="options" id="option1" autoComplete="off" checked />
										Active
									</label>
									<label className="btn btn-primary">
										<input type="radio" name="options" id="option2" autoComplete="off" />
										Radio
									</label>
									<label className="btn btn-primary">
										<input type="radio" name="options" id="option3" autoComplete="off" />
										Radio
									</label>
								</div>
							</div>
							<div>
								<hr />
							</div>
							<div>
								<div className="btn-group btn-group-toggle" data-toggle="buttons">
									<label className="btn btn-primary">
										<input type="checkbox" name="options[]" id="option1" autoComplete="off" checked />
										Active
									</label>
									<label className="btn btn-primary active">
										<input type="checkbox" name="options[]" id="option2" autoComplete="off" />
										Checkbox
									</label>
									<label className="btn btn-primary">
										<input type="checkbox" name="options[]" id="option3" autoComplete="off" />
										Checkbox
									</label>
								</div>
							</div>
						</div>

						<div className="mt-4">
							<div>
								<h2 className="text-primary">CSS Custom Checkbox and radio</h2>
								<h5>Radio</h5>
								<div className="custom-radio">
									<label htmlFor="check">
										<input type="radio" name="cssradio" id="check" autoComplete="off" checked />
										<span></span>checked
									</label>
									<label htmlFor="Normal">
										<input type="radio" name="cssradio" id="Normal" autoComplete="off" />
										<span></span>
										Normal
									</label>
									<label htmlFor="RadioDisabled">
										<input type="radio" name="cssradio" id="RadioDisabled" autoComplete="off" disabled />
										<span></span>
										<span>Radio Disabled</span>
									</label>
								</div>
							</div>							
							<hr />
							<div className="mb-3">
								<h5>Checkbox</h5>
								<div className="custom-checkbox">
									<label htmlFor="check1">
										<input type="checkbox" name="csscheckbox" id="check1" autoComplete="off" checked />
										<span></span>checked
									</label>
									<label htmlFor="Normal1">
										<input type="checkbox" name="csscheckbox" id="Normal1" autoComplete="off" />
										<span></span>
										Normal
									</label>
									<label htmlFor="checkboxDisabled1">
										<input type="checkbox" name="csscheckbox" id="checkboxDisabled1" autoComplete="off" disabled />
										<span></span>
										<span>Radio Disabled</span>
									</label>
								</div>
							</div>
						</div>

						<hr />
						<div>
							<div>
								<h2 className="text-primary">Switch Toggle</h2>
								<div className="custom-control custom-switch">
									<input type="checkbox" className="custom-control-input" id="switchCheckbox" />
									<label className="custom-control-label" htmlFor="switchCheckbox">Switch Checkbox</label>
								</div>
								<hr />

							</div>
						</div>

						<div>
							<div>
								<h2 className="text-primary">Base Form Controls</h2>
								<form>

									<Form.Group controlId="formBasicEmailAddress">
										<Form.Label>Email address</Form.Label>
										<Form.Control type="email" placeholder="Enter email" />
										<Form.Text className="text-muted">
											We'll never share your email with anyone else.
										</Form.Text>
									</Form.Group>
									<Form.Group controlId="example-datetime-local-input">
										<Form.Label>Date and time</Form.Label>
										<div className="datepicker">
											<DatePicker
												selected={ this.state.startDate }
												onChange={ this.handleChange }
												name="startDate"
												dateFormat="MM/dd/yyyy"
												className="form-control"
												/>
												<em className='bx bx-calendar'></em>
										</div>
									</Form.Group>
									<Form.Group controlId="exampleInputPassword1">
										<Form.Label>Password</Form.Label>
										<Form.Control type="password" placeholder="Enter email" />
									</Form.Group>
									<Form.Group controlId="formPlaintextEmail">
										<Form.Label>
											Static:
										</Form.Label>
										<Form.Control plaintext readOnly defaultValue="email@example.com" />
									</Form.Group>

									<Form.Group controlId="exampleForm.ControlTextarea1">
										<Form.Label>Example textarea</Form.Label>
										<Form.Control as="textarea" rows={3} />
									</Form.Group>
									<div className="btn-section">
										<Button className="mr-2" variant="primary">
											Submit
										</Button>
										<Button variant="secondary">
											Cancel
										</Button>
									</div>
								</form>
							</div>
						</div>

					</Container>

				</div>
			</Layout>
		);
	}
}
/********************
@purpose : Connect With Redux
@Parameter : {ui}
			@Author : INIC
			******************/
const mapStateToProps = ({ ui }) => ({});
export default connect(mapStateToProps)(Guidelines);
