import React, { Component, useState } from "react";
import { connect } from "react-redux";
import Slider from "react-slick";
import OtpInput from 'react-otp-input';
import Clamp from 'react-multiline-clamp';
import { Animated } from "react-animated-css";
import Sliders from 'react-rangeslider';
import { Container, Button, Modal, Accordion, Card, Tabs, Tab } from 'react-bootstrap';
import Layout from "../../components/layout";
import ReactStars from "react-rating-stars-component";
import NumberFormat from 'react-number-format';
import DatePicker from "react-datepicker";
import Select from 'react-select';

const ReactModal = () => {
	const [show, setShow] = useState(false);

	const handleClose = () => setShow(false);
	const handleShow = () => setShow(true);

	return (
		<>
			<Button variant="primary" onClick={handleShow}>
				Launch demo modal
			</Button>

			<Modal show={show} onHide={handleClose}>
				<Modal.Header closeButton>
					<Modal.Title>Modal heading</Modal.Title>
				</Modal.Header>
				<Modal.Body>Woohoo, you're reading this text in a modal!</Modal.Body>
				<Modal.Footer>
					<Button variant="secondary" onClick={handleClose}>
						Close
					</Button>
					<Button variant="primary" onClick={handleClose}>
						Save Changes
					</Button>
				</Modal.Footer>
			</Modal>
		</>
	);
};

class Plugins extends Component {
	/******************* 
	@purpose : Rander HTML/ React Components
	@Author : INIC
	******************/

	constructor(props, context) {
		super(props, context)
		this.state = {
			volume: 0,
			startDate: new Date(),
			_document: null
		}
		this.handleChange = this.handleChange.bind(this);
	}

	handleChange(date) {
		this.setState({
			startDate: date
		})
	}

	componentDidMount() {
		this.setState({
			_document: document
		})
	}

	// RangeSlider
	handleOnChange = (value) => {
		this.setState({
			volume: value
		})
	}
	state = { otp: '' };
	handleChange1 = (otp) => this.setState({ otp });

	render() {

		// SlickSlider
		var settings = {
			dots: true,
			infinite: true,
			speed: 500,
			slidesToShow: 3,
			slidesToScroll: 1
		};

		// RangeSlider
		let { volume, _document } = this.state

		// ReactSelect Options
		var options = ["apple", "mango", "grapes", "melon", "strawberry"].map(function (fruit) {
			return { label: fruit, value: fruit }
		});


		return (
			<Layout>

				<div className="flex-shrink-0 my-5">
					<Container>



						{/* React Select */}
						<h2 className="text-primary">React Select</h2>
						<Select
							options={options}
						/>

						<h5 className="text-primary mt-3">React Multi Select</h5>
						<Select
							options={options}
							isMulti
						/>

						<h5 className="text-primary mt-3">Append to Body</h5>
						<Select
							options={options}
							menuPortalTarget={_document?.querySelector('body')}
						/>
						<hr />

						{/* Slick Slider */}
						<h2 className="text-primary">Slick Slider</h2>
						<Slider {...settings} className="mb-5">
							<div>
								<h3>1</h3>
							</div>
							<div>
								<h3>2</h3>
							</div>
							<div>
								<h3>3</h3>
							</div>
							<div>
								<h3>4</h3>
							</div>
							<div>
								<h3>5</h3>
							</div>
							<div>
								<h3>6</h3>
							</div>
						</Slider>

						<hr />

						{/* OTP Input */}
						<h2 className="text-primary">OTP Input</h2>
						<OtpInput
							value={this.state.otp}
							onChange={this.handleChange1}
							numInputs={6}
							separator={<span>-</span>}
							className="otp-input"
							isInputSecure={true}
							isInputNum={true}
						// inputStyle='form-control'
						/>
						<hr />

						{/* Number Format */}
						<h2 className="text-primary">Number Format</h2>
						<NumberFormat
							thousandsGroupStyle="thousand"
							value={2456981}
							prefix="$"
							decimalSeparator="."
							displayType="input"
							type="text"
							thousandSeparator={true}
							allowNegative={true}
							className="form-control"
						/>

						<hr />

						{/*  Date Picker */}
						<h2 className="text-primary">React Date Picker</h2>
						<div className="datepicker">
							<DatePicker
								selected={this.state.startDate}
								onChange={this.handleChange}
								name="startDate"
								dateFormat="MM/dd/yyyy"
								className="form-control"
							/>
							<em className='bx bx-calendar'></em>
						</div>

						<hr />

						{/* Line Clamp */}
						<h2 className="text-primary">Line Clamp</h2>
						<Clamp withTooltip lines={2}>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
						</Clamp>
						<h5 className="text-primary">With hide and show</h5>
						<Clamp
							lines={3}
							maxLines={6}
							withToggle
							showMoreElement={({ toggle }) => (
								<Button type="button" variant="primary" onClick={toggle}>
									Show more
								</Button>
							)}
							showLessElement={({ toggle }) => (
								<Button type="button" variant="secondary" onClick={toggle}>
									Show less
								</Button>
							)}
						>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>

						</Clamp>
						<hr />

						{/* Animate Css */}
						<h2 className="text-primary">Animate Css</h2>
						<Animated animationIn="bounceInLeft" animationOut="fadeOut" isVisible={true}>
							<div>
								hello world ;)
							</div>
						</Animated>
						<hr />

						{/* Star Rating */}
						<h2 className="text-primary">Star Rating</h2>
						<ReactStars
							count={5}
							size={24}
							activeColor="#13615a"
						/>
						<hr />

						{/* Range Slider */}
						<h2 className="text-primary">Range Slider</h2>
						<Sliders
							value={volume}
							onChange={this.handleOnChange}
						/>
						<h5 className="text-primary">vertical</h5>
						<Sliders
							value={volume}
							orientation="vertical"
							onChange={this.handleOnChange}
						/>

						<hr />

						{/* React Modal */}
						<h2 className="text-primary mt-4">React Modal</h2>
						<ReactModal />

						<hr />

						{/* React Accordion */}
						<h2 className="text-primary mt-4">React Accordion</h2>
						<Accordion defaultActiveKey="0">
							<Card>
								<Accordion.Toggle as={Card.Header} eventKey="0">
									Click me!
								</Accordion.Toggle>
								<Accordion.Collapse eventKey="0">
									<Card.Body>Hello! I'm the body</Card.Body>
								</Accordion.Collapse>
							</Card>
							<Card>
								<Accordion.Toggle as={Card.Header} eventKey="1">
									Click me!
								</Accordion.Toggle>
								<Accordion.Collapse eventKey="1">
									<Card.Body>Hello! I'm another body</Card.Body>
								</Accordion.Collapse>
							</Card>
						</Accordion>

						<hr />

						{/* React Tabs */}
						<h2 className="text-primary mt-4">React Tabs</h2>
						<Tabs defaultActiveKey="home" id="uncontrolled-tab-example">
							<Tab eventKey="home" title="Home">
								How can my muse want subject to invent, While thou dost breathe, that pour'st into my verse Thine own sweet argument, too excellent For every vulgar paper to rehearse? O! give thy self the thanks, if aught in me Worthy perusal stand against thy sight; For who's so dumb that cannot write to thee, When thou thy self dost give invention light? Be thou the tenth Muse, ten times more in worth Than those old nine which rhymers invocate;
							</Tab>
							<Tab eventKey="profile" title="Profile">
								Those lips that Love's own hand did make, Breathed forth the sound that said 'I hate', To me that languish'd for her sake: But when she saw my woeful state, Straight in her heart did mercy come, Chiding that tongue that ever sweet Was us'd in giving gentle doom; And taught it thus anew to greet; 'I hate' she alter'd with an end, That followed it as gentle day,
							</Tab>
						</Tabs>

					</Container>
				</div>
			</Layout>

		);
	}
}
/********************
@purpose : Connect With Redux
@Parameter : {ui}
			@Author : INIC
			******************/
const mapStateToProps = ({ ui }) => ({});
export default connect(mapStateToProps)(Plugins);
