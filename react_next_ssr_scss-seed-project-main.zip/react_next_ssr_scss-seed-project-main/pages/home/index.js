import React, { Component } from "react";
import { connect } from "react-redux";
import Link from 'next/Link'
import { Container, Row } from 'react-bootstrap';

class Home extends Component {
	/******************* 
	@purpose : Rander HTML/ React Components
	@Author : INIC
	******************/
	render() {
		return (
			<Container>
				<div data-splitting=''>Hello World!</div>
				<div className="mt-5">
					<Link href="/guidelines">
						<a className="btn btn-primary mr-2">Guidelines</a></Link>
					<Link href="/plugins"><a className="btn btn-secondary  mr-2">Plugins</a></Link>
					<Link href="/ag-grid"><a className="btn btn-light">Ag Grid Table</a></Link>
				</div>
			</Container>

		);
	}
}
/********************
@purpose : Connect With Redux
@Parameter : {ui}
			@Author : INIC
			******************/
const mapStateToProps = ({ ui }) => ({});
export default connect(mapStateToProps)(Home);
