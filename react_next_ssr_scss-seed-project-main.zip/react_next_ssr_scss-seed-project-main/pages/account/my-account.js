import React, { Component } from "react";
import { connect } from "react-redux";
import Layout from "./../../components/layout";

class MyAccount extends Component {
  /******************* 
  @purpose : Rander HTML/ React Components
  @Author : INIC
  ******************/
  render() {
    return (
      <Layout>
        <div className="my-account">My-account page</div>
      </Layout>
    );
  }
}
/******************** 
@purpose : Connect With Redux
@Parameter : {ui}
@Author : INIC
******************/
const mapStateToProps = ({ ui }) => ({});
export default connect(mapStateToProps)(MyAccount);
