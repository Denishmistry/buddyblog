var gulp = require('gulp');
var scss = require('gulp-sass');
var concat = require('gulp-concat');
var browserSync = require('browser-sync').create();
var minify = require("gulp-minify");
var webp = require('gulp-webp');

// ScSS files compilor task
gulp.task('scss', function() {
    return gulp.src([
        'assets/css/boxicons_2.0.5.min.css',
        'assets/scss/**/*.scss'], { allowEmpty: true })
        .pipe(scss({outputStyle: 'compressed'}).on('error', scss.logError))
        .pipe(concat('style-min.css'))
        .pipe(minify({noSource: true}))
        .pipe(gulp.dest('assets/css'))
        .pipe(browserSync.stream());
});
// Client javascript
gulp.task("javascript", function () {
    return gulp.src([
        'node_modules/jquery/dist/jquery.min.js', 
        'node_modules/bootstrap/dist/js/bootstrap.bundle.js',
        'assets/js/custom.js'], { allowEmpty: true }) 
        .pipe(concat('minify/javascript-lib.js'))
        .pipe(minify({noSource: true}))
        .pipe(gulp.dest('assets/js'))
        .pipe(browserSync.stream());
});
// Optimize Images
gulp.task('imgwebp', () =>
    gulp.src('assets/images/**/*.{jpg,png}')
    .pipe(webp())
    .pipe(gulp.dest('assets/images'))
);

// Watch Task upto gulp version 3.9.1
// gulp.task('serve', function() {
//     browserSync.init({
//         server: "./"
//     });
//     gulp.watch("assets/scss/**/*.scss", ['scss']);
//     gulp.watch("assets/js/*.js", ['javascript']);
//     gulp.watch("assets/images/*.{jpg,png}", ['imgwebp']);
//     gulp.watch("*.html").on('change', browserSync.reload); 
// });

// gulp.task('default', ['serve','scss', 'javascript', 'imgwebp']);

// IF Node.js ^14+ & Gulp: ^4.00 made below code uncomment and above watch task comment
// Watch Task above gulp version 4.0.0
gulp.task('serve', function() {
    browserSync.init({
        server: "./"
    });
    gulp.watch("assets/scss/**/*.scss", gulp.series('scss'));
    gulp.watch("assets/js/*.js", gulp.series('javascript'));
    gulp.watch("assets/images/*.{jpg,png}", gulp.series('imgwebp'));
    gulp.watch("*.html").on('change', browserSync.reload); 
});

gulp.task('default', gulp.series(['serve','scss','javascript','imgwebp']));