(function ($) {
    /* Document Ready State */
    jQuery(document).ready(function(){
        //show password
        $(".toggle-password").on("click", function() {
          $(this).toggleClass("bx-show bx-hide");
          var input = $($(this).attr("toggle"));
          if (input.attr("type") == "password") {
            input.attr("type", "text");
          } else {
            input.attr("type", "password"); 
          }
        });
    });
})(jQuery);